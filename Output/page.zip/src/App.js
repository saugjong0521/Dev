import logo from './logo.svg';
import './App.css';
import {BrowserRouter, Route, Routes} from 'react-router-dom'
import GlobalNavigationBar from './page/header/Gnb';
import TranslateChat from './page/content/translateChat/TranslateChat';
import LoginPage from './page/content/LoginPage';
import Layout from './page/Layout';
import Register from './page/content/translateChat/Register';


function App() {
  return (

    <BrowserRouter>
      <Routes>
          <Route path='/' element={<LoginPage/>}/>
          <Route path='/register' element={<Register/>}/>

          <Route element={<Layout/>}>
            <Route path='/translateChat' element={<TranslateChat/>}/>
          </Route>
          
      </Routes>          
    </BrowserRouter>

  );
}

export default App;
