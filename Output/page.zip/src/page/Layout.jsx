import { Outlet } from "react-router-dom";
import GlobalNavigationBar from "./header/Gnb";


export default function Layout (){

    return (
        <>
        <GlobalNavigationBar/>
        <main>
            <Outlet/>
        </main>
        </>
    )

}