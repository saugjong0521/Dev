import { useState } from 'react'
import './LoginPage.css'
import { Link, useNavigate } from 'react-router-dom';


export default function LoginPage (){

    const navigate = useNavigate()

    const [userID, setUserID] = useState('');
    const [userPW, setUserPW] = useState('');
    const [message, setMessage] = useState('');

    const handleLogin = (e) => {
        e.preventDefault();
        if (userID === 'root' && userPW === '1234'){//이부분에 유저 데이터 베이스를 적용
            setMessage('')
            navigate('/translateChat')//맞을시 translateChat 컴포넌트로 변경
        }else{
            setMessage('wrong accout information')//틀릴 시 메시지 표출
        }
    }

    return (

        <>
        <div className="login-page-container">
            <div className="login-page-box">
                <div className="login-page-theme">로그인 페이지</div>
                
                <div className="login-page-input-container">
                    <form>
                        <div className="login-item-box">
                            <input type="text"
                                className='login-inputbox-id'
                                placeholder='아이디를 입력하세요'
                                value={userID}
                                onChange={(e)=>setUserID(e.target.value)}/>
                        </div>   
                        <div className="login-item-box"> 
                            <input type="password"
                                className='login-inputbox-pw'
                                placeholder='패스워드를 입력하세요'
                                value={userPW}
                                onChange={(e)=>setUserPW(e.target.value)}/>
                        </div>   
                        <div className="login-item-box">  
                            <button className='login-btn' onClick={handleLogin}>Sign-in</button>
                        </div>   
                        <div className="message-box">
                            {message && <p style={{color: 'red'}}>{message}</p>}
                        </div>
                    </form>
                </div>
                <div className="register-wrapper">
                    <button className="register-btn">
                        <Link to="/register" style={{textDecoration: 'none', color: 'black'}}>Sign-up</Link>
                    </button>
                </div>
            </div>

        </div>
        
        </>
    )

}