import './TranslateChat.css';


export default function TranslateChat() {


    return (

        <>
            <div className="hidden-box"></div>
            <div className="TranslateChat-container">
                <div className="TranslateChat-wrapper">
                    
                    <div className="roomlist-container">
                        <div className="">roomlist content</div>
                    </div>
                    <div className="userlist-mobile-container">
                    </div>


                    <div className="mainbody-container">
                        <div className="setting-container">
                            <div className="default-setting-container"></div>
                            <div className="toggle-setting-container"></div>
                        </div>
                        <div className="chattingroom-container"></div>
                        <div className="chattingox-container"></div>
                    </div>

                    <div className="userlist-container">

                    </div>

                </div>
            </div>
        </>

    )
}