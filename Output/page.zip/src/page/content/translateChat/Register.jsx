import { useState } from 'react';
import './Register.css';

export default function Register() {
    const [isAlertShown, setIsAlertShown] = useState(false);

    const alertEmail = () => {
        alert('이메일이 발송되었습니다.');
        setIsAlertShown(true); // alert가 표시된 후 상태 업데이트
    }

    const handleSubmit = (e) => {
        e.preventDefault();

        const form = e.target;
        if (form.checkValidity()) {
            alertEmail();
        } else {
            form.reportValidity();
        }
    }

    // alert 확인 후 페이지 이동 처리
    if (isAlertShown) {
        window.location.href = '/'; // 원하는 경로로 페이지 전환
    }

    return (
        <div className="register-page-container">
            <div className="register-box">
                <form className='register-form' onSubmit={handleSubmit}>
                    <div className="register-item">
                        <label>ID</label>
                        <input 
                            type="text"
                            name="id"
                            className='register-input-item'
                            required
                        />
                    </div>

                    <div className="register-item">
                        <label>Password</label>
                        <input 
                            type="password"
                            name="password"
                            className='register-input-item'
                            required
                        />
                    </div>

                    <div className="register-item">
                        <label>E-mail</label>
                        <input 
                            type="email"
                            name="email"
                            className='register-input-item'
                            required
                        />
                    </div>

                    <div className="register-item">
                        <label>Nickname</label>
                        <input 
                            type="text"
                            name="nickname"
                            className='register-input-item'
                            required
                        />
                    </div>

                    <div className="register-item">
                        <button type="submit" className='register-btn'>
                            Submit
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
}
