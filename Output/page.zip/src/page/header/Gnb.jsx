import { Link } from 'react-router-dom';
import './Gnb.css';

export default function GlobalNavigationBar() {


    return (
        <>
            <div className="Gnb-container">
                <div className="logo-container">
                    <div className="logo"></div>
                </div>
                <ul className="mainmenu-container">
                    <li className="item1"><Link to='/translateChat'>TranslateChat</Link></li>
                    <li className="item2"></li>
                    <li className="item3"></li>
                    <li className="item4"></li>
                </ul>
                <div className="submenu-container"></div>
            </div>
        </>
    )
}

